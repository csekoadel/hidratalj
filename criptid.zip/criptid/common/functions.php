<?php

function generateNav(string $actualPage){
    echo "<nav><a href='index.php'>eriggy kriptid</a>".

    "<ul>" .
        "<li" . ($actualPage === "index" ? " class='active'" : "") . ">" .
        "<a href='index.php'>Kezdőlap</a>" .
        "</li>" .
        "<li" . ($actualPage === "about" ? " class='active'" : "") . ">" .
        "<a href='about.php'>Rólunk</a>" .
        "</li>" .
        "<li" . ($actualPage === "beasts" ? " class='active'" : "") . ">" .
        "<a href='beast.php'>Bestiárium</a>" .
        "</li>".
        "<li" . ($actualPage === "bundles" ? " class='active'" : "") . ">" .
        "<a href='bundles.php'>Csomagjaink</a>" .
        "</li>";

    if (isset($_SESSION["user"])){
        if($_SESSION["user"]->getUsername() === "admin"){
            echo "<li" . ($actualPage === "orders" ? " class='active'" : "") . ">" .
                "<a href='orders.php'>Rendelések</a>" .
                "</li>";
        }else{
            echo "<li" . ($actualPage === "cart" ? " class='active'" : "") . ">" .
                "<a href='cart.php'>Kosaram</a>" .
                "</li>";
        }

        echo "<li" . ($actualPage === "profile" ? " class='active'" : "") . ">" .
            "<a href='profile.php'>Profilom</a>" .
            "</li>" .
            "<li" . ($actualPage === "friends" ? " class='active'" : "") . ">" .
            "<a href='friends.php'>Barátok</a>" .
            "</li>" .
            "</ul></nav>";
    }else{
        echo "<li" . ($actualPage === "login" ? " class='active'" : "") . ">" .
            "<a href='login.php'>Bejelentkezés</a>" .
            "</li>" .
            "<li" . ($actualPage === "signup" ? " class='active'" : "") . ">" .
            "<a href='signup.php'>Regisztráció</a>" .
            "</li>" .
            "</ul></nav>";
    }
}


function saveData(string $filename, array $datas){
    $file = fopen($filename, "w");

    if(!$file){
        die("Nem sikerült a fájl megnyitása!");
    }

    foreach($datas as $data){
        fwrite($file, serialize($data) . "\n");
    }

    fclose($file);
}

function loadData(string $filename): array{
    $file = fopen($filename, "r");
    $datas = [];

    if (!$file){
        die("Nem sikerült a fájlt megnyitni!");
    }

    while(($row = fgets($file)) !== false){
        $data = unserialize($row);
        $datas[] = $data;
    }

    fclose($file);
    return $datas;
}

function editUsers(string $filename, User $editUser){
    $users = loadData($filename);

    foreach ($users as &$user){
        if ($user->getUsername() === $editUser->getUsername()) {
            $user = $editUser;
        }
    }
    saveData($filename, $users);
}


function total(array $cart){
    $sum = 0;

    foreach ($cart as $item) {
        $sum += $item->getPrice();
    }
    return $sum;
}

function uploadProfilePicture(array &$errors, string $username){
    if (isset($_FILES["profile-picture"]) && is_uploaded_file($_FILES["profile-picture"]["tmp_name"])){
        if($_FILES["profile-picture"]["error"] !== 0) {
            $errors[] = "Hiba történt a fájl feltöltése során!";
        }

        $allowedFormats = ["png", "jpg", "jpeg"];
        $format = strtolower(pathinfo($_FILES["profile-picture"]["name"], PATHINFO_EXTENSION));

        if(!in_array($format, $allowedFormats)){
            $errors[] = "A profilkép kiterjesztése hibás! Engedélyezett formátumok: " .
                implode(", ", $allowedFormats) . "!";
        }

        if($_FILES["profile-picture"]["size"] > 5242880){
            $errors[] = "A fájl mérete túl nagy!";
        }

        if(count($errors) === 0){
            $route = "assets/img/profile-pictures/$username.$format";
            $flag = move_uploaded_file($_FILES["profile-picture"]["tmp_name"], $route);

            if(!$flag){
                $errors[] = "A profilkép elmentése nem sikerült!";
            }
        }
    }
}