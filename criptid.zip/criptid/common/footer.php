<footer>
    <p class="kozepre">&copy;Facebook</p>
    <p class="kozepre">&copy;E-mail</p>
    <p class="kozepre">&copy;Telefonszám: +36204206660</p>
</footer>