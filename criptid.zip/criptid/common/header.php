<header>
    <h1 class="kozepre">eriggy kriptid</h1>
</header>