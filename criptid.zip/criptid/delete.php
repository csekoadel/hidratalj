<?php

session_start();

if (!isset($_SESSION["user"])) {
    header("Location: profile.php");
}




header("Location: profile.php");
