<?php
include_once "classes/User.php";
include_once "common/functions.php";
session_start();
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <title>Főoldal</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="assets/img/icon.png">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php
include_once "common/header.php";
generateNav("index");
?>

<!-- TOP CONTAINER -->
<div class="top-container">
    <h1><div class="waviy">
            <span style="--i:1">Ü</span>
            <span style="--i:2">d</span>
            <span style="--i:3">v</span>
            <span style="--i:4">ö</span>
            <span style="--i:5">z</span>
            <span style="--i:6">ö</span>
            <span style="--i:7">l</span>
            <span style="--i:8">l</span>
            <span style="--i:9">e</span>
            <span style="--i:10">k</span>
            <span style="--i:11">!</span>
        </div></h1>
    <p>Cégünket, az Eriggy Kriptid Kft-t, 2020-ban az első karantén alatt hoztuk létre.</p>
    <p>Hogy mi volt a célunk?</p>
    <p>A világbéke!</p>
    <p>Ja nem,</p>
    <p>.</p>
    <p>.</p>
    <p>.</p>
    <p>az unaloműzés.</p>
</div>

<!-- SLIDESHOW   -->
<div class="middle-container-home">
    <div class="slideshow">
        <div class="myslides fade">
            <img src="assets/img/carousel/kraken.jpeg"  class="myslides-s-1" >
            <div class="img-txt">Kraken</div>
        </div>
        <div class="myslides fade">
            <img src="assets/img/carousel/jeti.jpeg" class="myslides-s-1">
            <div class="img-txt">Jeti</div>
        </div>
        <div class="myslides fade">
            <img src="assets/img/carousel/lochness.jpeg" class="myslides-s-1">
            <div class="img-txt">Lochness</div>
        </div>
        <div class="myslides fade">
            <img src="assets/img/carousel/bigfoot.jpeg" class="myslides-s-1">
            <div class="img-txt">Nagylab</div>
        </div>

        <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
        <a class="next" onclick="plusSlides(1)">&#10095;</a>
    </div>
</div>

<!-- JAVASCRIPT -->
<script src="js/script.js"></script>
<?php
include_once "common/footer.php";
?>
</body>
</html>