<?php
include_once "classes/User.php";
include_once "common/functions.php";
session_start();

    if (!isset($_SESSION["user"])) {
        header("Location: login.php");
    }

    $friends = loadData("data/users.txt");

?>

    <!DOCTYPE html>
    <html lang="hu">
    <head>
        <title>Barátok</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" href="assets/img/icon.png">
        <link rel="stylesheet" href="assets/css/style.css">
    </head>
    <body>
    <?php
    include_once "common/header.php";
    generateNav("friends");
    ?>

<main>
    <h1 class="kozepre">Barátok</h1>
    <hr>

    <table id="friends-table">
        <tr>
            <th>Felhasználónév</th>
            <th>Születési év</th>
            <th>Nem</th>
        </tr>
        <?php foreach ($friends as $friend) { ?>
        <tr>
            <td>
                <b><?php echo $friend->getUsername(); ?></b>
            </td>
            <td><?php echo $friend->getYearOfBirth(); ?></td>
            <td><?php echo $friend->getGender(); ?></td>
        </tr>
        <?php } ?>
    </table>
</main>

<?php
include_once "common/footer.php";
?>
    </body>
</html>
