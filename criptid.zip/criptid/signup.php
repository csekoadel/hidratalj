<?php
    include_once "classes/User.php";
    include_once "common/functions.php";
    session_start();

    $users = loadData("data/users.txt");

    $errors = [];

    if (isset($_POST["signup-btn"])) {
        $username = $_POST["username"];
        $password = $_POST["password"];
        $passwordCheck = $_POST["password2"];
        $email = $_POST["email"];
        $yearOfBirth = $_POST["year-of-birth"];
        $gender = "egyéb";
        $checkBoxes = [];

        if (isset($_POST["gender"])) {
            $gender = $_POST["gender"];
        }

        if (isset($_POST["confirmations"])) {
            $checkBoxes = $_POST["confirmations"];
        }

        if (trim($username) === "" || trim($password) === "" || trim($passwordCheck) === "" ||
            trim($email) === "" || trim($yearOfBirth) === "") {
            $hibak[] = "Minden kötelezően kitöltendő mezőt ki kell tölteni!";
        }

        foreach ($users as $user) {
            if ($user->getUsername() === $username) {
                $hibak[] = "A felhasználónév már foglalt!";
            }
        }

        if ($username === "default") {
            $hibak[] = "A felhasználónév már foglalt!";
        }

        if (strlen($password) < 5) {
            $hibak[] = "A jelszónak legalább 5 karakter hosszúnak kell lennie!";
        }

        if (!preg_match("/[A-Za-z]/", $password) || !preg_match("/[0-9]/", $password)) {
            $hibak[] = "A jelszónak tartalmaznia kell betűt és számjegyet is!";
        }

        if (!preg_match("/[0-9a-z.-]+@([0-9a-z-]+\.)+[a-z]{2,4}/", $email)) {
            $hibak[] = "A megadott e-mail cím formátuma nem megfelelő!";
        }

        if ($password !== $passwordCheck) {
            $hibak[] = "A két jelszó nem egyezik!";
        }

        foreach ($users as $user) {
            if ($user->getEmail() === $email) {
                $hibak[] = "Az e-mail cím már foglalt!";
            }
        }

        uploadProfilePicture($errors, $username);

        if (count($checkBoxes) < 2) {
            $hibak[] = "Mindkét jelölőnégyzetet be kell jelölni!";
        }

        if (count($hibak) === 0) {
            $password = password_hash($password, PASSWORD_DEFAULT);
            $user = new User($username, $password, $email, $yearOfBirth, $gender);
            $users[] = $user;
            saveData("data/users.txt", $users);
            header("Location: signup.php?siker=true");
        }
    }
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <title>Regisztráció</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="assets/img/icon.png">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php
        include_once "common/header.php";
        generateNav("signup");
    ?>

    <main class="signup-main">
        <h1 class="center">Regisztráció</h1>

        <?php
            if (isset($_GET["siker"])) {
                echo "<div class='success'><p>Sikeres regisztráció!</p></div>";
            }

            // A regisztráció során előforduló esetleges hibák kiíratása.

            if (count($hibak) > 0) {
                echo "<div class='errors'>";

                foreach ($hibak as $hiba) {
                    echo "<p>" . $hiba . "</p>";
                }

                echo "</div>";
            }
        ?>

        <div class="form-container">
            <form action="signup.php" method="POST" autocomplete="off" enctype="multipart/form-data">
                <label for="username" class="required-label">Felhasználónév</label>
                <input type="text" name="username" id="username" placeholder="Felhasználónév" required
                    <?php if (isset($_POST["username"])) echo "value='" . $_POST["username"] . "'" ?>>

                <label for="password" class="required-label">Jelszó</label>
                <input type="password" name="password" id="password" placeholder="Jelszó" required>

                <label for="passsword2" class="required-label">Jelszó újra</label>
                <input type="password" name="password2" id="password2" placeholder="Jelszó" required>

                <label for="email" class="required-label">E-mail cím</label>
                <input type="email" name="email" id="email" placeholder="E-mail" required
                    <?php if (isset($_POST["email"])) echo "value='" . $_POST["email"] . "'" ?>>

                <label for="yob" class="required-label">Születési év</label>
                <input type="number" name="year-of-birth" id="yob" placeholder="Születési év" required
                    <?php if (isset($_POST["year-of-birth"])) echo "value='" . $_POST["year-of-birth"] . "'" ?>>

                <div class="radio-button-container">
                    Nem:
                    <label>
                        <input type="radio" name="gender" value="férfi"
                            <?php if (isset($_POST["gender"]) && $_POST["gender"] === "férfi") echo "checked"; ?>>
                        Férfi
                    </label>
                    <label>
                        <input type="radio" name="gender" value="nő"
                            <?php if (isset($_POST["gender"]) && $_POST["gender"] === "nő") echo "checked"; ?>>
                        Nő
                    </label>
                    <label>
                        <input type="radio" name="gender" value="egyéb"
                            <?php if (!isset($_POST["gender"]) || $_POST["gender"] === "egyéb") echo "checked"; ?>>
                        Egyéb
                    </label>
                </div>

                <label for="avatar">Profilkép: </label>
                <input type="file" name="profile-picture" id="avatar">

                <div class="checkbox-container">
                    <label class="required-label">
                        <input type="checkbox" name="confirmations[]" value="confirm-data" required>
                        A megadott adatok a valóságnak megfelelnek!
                    </label>
                    <label class="required-label">
                        <input type="checkbox" name="confirmations[]" value="accept-terms-and-conditions" required>
                        Elfogadom a <a href="https://www.youtube.com/watch?v=zqLEO5tIuYs">felhasználási feltételeket</a>.
                    </label>
                </div>

                <input type="submit" name="signup-btn" class="signup-btn" value="Regisztráció">
                <input type="reset" name="reset-btn" class="reset-btn" value="Visszaállítás">
                <a class="masik" href="login.php">Már van fiókja? Itt tud bejelentkezni!</a>
            </form>
        </div>
    </main>

    <?php
        include_once "common/footer.php";
    ?>
</body>
</html><?php
