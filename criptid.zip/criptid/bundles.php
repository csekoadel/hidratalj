<?php
include_once "classes/User.php";
include_once "classes/Beast.php";
include_once "classes/CartItem.php";
include_once "common/functions.php";
session_start();

$beasts = loadData("data/beasts.txt");

if (isset($_SESSION["user"]) && isset($_GET["add-to-cart-btn"])) {
    $user = $_SESSION["user"];
    $cart = $user->getCart();

    $beastName = $_GET["beast-name"];

    foreach ($beasts as $beast) {
        if ($beast->getName() === $beastName) {
            $item = new CartItem($beast);
            $user->putInCart($item);
        }
    }

    editUsers("data/users.txt", $user);
    header("Location: bundles.php?success=true");
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <title>Csomagjaink</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="assets/img/icon.png">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php
include_once "common/header.php";
generateNav("bundles");
?>

<main>
    <h1 class="center">Csomagjaink</h1>
    <hr>

    <?php
    if (isset($_GET["success"])) {
        echo "<div class='success'><p>A csomagot sikeresen a kosárba helyezte!</p></div>";
    }
    ?>


    <table>
        <tr>
            <th>Kriptid neve</th>
            <th>Felszerelés</th>
            <th>Ár</th>
            <?php if (isset($_SESSION["user"])) { ?>
                <th>Kosárba tétel</th>
            <?php } ?>
        </tr>
        <?php foreach ($beasts as $beast) { ?>
            <tr>
                <td>
                    <b><?php echo $beast->getName(); ?></b>
                </td>
                <td>
                    <?php echo implode(", ", $beast->getEquipment()); ?>
                </td>
                <td>
                    <?php echo $beast->getPrice() . "Ft"; ?>
                </td>
                <?php if (isset($_SESSION["user"])) { ?>
                    <td>
                        <form action="bundles.php" method="GET">
                            <input type="hidden" name="beast-name" value="<?php echo $beast->getName(); ?>">
                            <input type="submit" name="add-to-cart-btn" class="add-to-cart-btn" value="Kosárba">
                        </form>
                    </td>
                <?php } ?>
            </tr>
        <?php } ?>
    </table>
</main>

<?php
include_once "common/footer.php";
?>
</body>
</html>