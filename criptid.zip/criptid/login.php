<?php
    include_once "classes/User.php";
    include_once "common/functions.php";
    session_start();

    $users = loadData("data/users.txt");
    $succesfulLogin = true;

    if (isset($_POST["login-btn"])) {
        $username = $_POST["username"];
        $password = $_POST["password"];

        foreach ($users as $user) {
            if ($user->getUsername() === $username && password_verify($password, $user->getPassword())) {
                $_SESSION["user"] = $user;
                header("Location: profile.php");
            }
        }
        $succesfulLogin = false;
    }
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <title>Bejelentkezés</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="assets/img/icon.png">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php
        include_once "common/header.php";
        generateNav("login");
    ?>

    <main class="login-main">
        <h1 class="center">Bejelentkezés</h1>

        <?php
            if (!$succesfulLogin) {
                echo "<div class='errors'><p>A belépési adatok nem megfelelőek!</p></div>";
            }
        ?>

        <div class="form-container">
            <form action="login.php" method="POST" autocomplete="off">
                <label for="username" class="required-label">Felhasználónév: </label>
                <input type="text" placeholder="Felhasználónév" name="username" id="uname" required>

                <label for="password" class="required-label">Jelszó: </label>
                <input type="password" placeholder="Jelszó" name="password" id="passwod" required>

                <input type="submit" name="login-btn" class="login-btn" value="Bejelentkezés">
                <a class="masik" href="signup.php">Még nincs fiókja? Itt tud regisztrálni!</a>
            </form>
        </div>
    </main>

    <?php
        include_once "common/footer.php";
    ?>
</body>
</html>