<?php
    include_once "classes/User.php";
    include_once "classes/CartItem.php";
    include_once "classes/Order.php";
    include_once "common/functions.php";
    session_start();

    if (!isset($_SESSION["user"])) {
        header("Location: login.php");
    }

    if ($_SESSION["user"]->getUsername() !== "admin") {
        header("Location: index.php");
    }

    $orders = loadData("data/orders.txt");

    $notPerformedOrders = [];
    $performedOrders = [];

    foreach ($orders as $order) {
        if ($order->isPerformed()) {
            $performedOrders[] = $order;
        } else {
            $notPerformedOrders[] = $order;
        }
    }

    if (isset($_GET["complete-order-btn"])) {
        $customer = $_GET["orderer"];
        $orederDate = $_GET["order-date"];

        foreach ($orders as $order) {
            if ($order->getCustomer() === $customer &&
                $order->getOrederDate()->format("Y-m-d H:i:s") === $orederDate) {
                $order->setPerformed(true);
            }
        }

        saveData("data/orders.txt", $orders);
        header("Location: orders.php");
    }
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <title>Rendelések</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="assets/img/icon.png">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php
        include_once "common/header.php";
        generateNav("orders");
    ?>

    <main>
        <h1 class="center">Rendelések</h1>

        <?php if (count($orders) > 0) { ?>
            <?php if (count($notPerformedOrders) > 0) { ?>
                <h2 class="kozepre">Aktív rendelések</h2>
                <table>
                    <tr>
                        <th>Rendelést feladó felhasználó</th>
                        <th>Rendelés dátuma</th>
                        <th>Rendelés tartalma</th>
                        <th></th>
                    </tr>
                    <?php foreach ($notPerformedOrders as $order) { ?>
                    <tr>
                        <td><?php echo $order->getCustomer(); ?></td>
                        <td><?php echo $order->getOrederDate()->format("Y-m-d H:i:s"); ?></td>
                        <td><?php echo implode("<br>", $order->getOrderContent()); ?></td>
                        <td>
                            <form action="orders.php" method="GET" class="complete-order-form">
                                <input type="hidden" name="orderer"
                                       value="<?php echo $order->getCustomer(); ?>">
                                <input type="hidden" name="order-date"
                                       value="<?php echo $order->getOrederDate()->format('Y-m-d H:i:s'); ?>">
                                <input type="submit" name="complete-order-btn" class="complete-order-btn" value="Teljesítés">
                            </form>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
            <?php } ?>

            <?php if (count($performedOrders) > 0) { ?>
                <hr>
                <h2 class="kozepre">Teljesített rendelések</h2>
                <table>
                    <tr>
                        <th>Rendelést feladó felhasználó</th>
                        <th>Rendelés dátuma</th>
                        <th>Rendelés tartalma</th>
                    </tr>
                    <?php foreach ($performedOrders as $order) { ?>
                    <tr>
                        <td><?php echo $order->getCustomer(); ?></td>
                        <td><?php echo $order->getOrederDate()->format("Y-m-d H:i:s"); ?></td>
                        <td><?php echo implode("<br>", $order->getOrderContent()); ?></td>
                    </tr>
                    <?php } ?>
                </table>
            <?php } ?>
        <?php } else { ?>
            <p class="center strong">Még nem érkezett rendelés!</p>
        <?php } ?>
    </main>

    <?php
        include_once "common/footer.php";
    ?>
</body>
</html>