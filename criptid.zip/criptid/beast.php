<?php
include_once "classes/User.php";
include_once "common/functions.php";
session_start();
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <title>Bestiárium</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="assets/img/icon.png">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php
include_once "common/header.php";
generateNav("beasts");
?>

<div class="top-container-beasts">
    <div class="h-beasts">
        <h1 class="h1-beasts">Bestiárium</h1>
    </div>
    <section class="cards-section">

        <div class="cards">
            <div class="card-container">
                <div class="card-front">
                    <img src="assets/img/beasts/wendigo.jpg" alt="Wendigo">
                </div>
                <div class="card-back">
                    <h1>Wendigo</h1>
                </div>
            </div>
        </div>

        <div class="cards">
            <div class="card-container">
                <div class="card-front">
                    <img src="assets/img/beasts/cockatrice.jpg" alt="Cockatrice">
                </div>
                <div class="card-back">
                    <h1>Cockatrice</h1>
                </div>
            </div>
        </div>

        <div class="cards">
            <div class="card-container">
                <div class="card-front">
                    <img src="assets/img/beasts/jeti.jpg" alt="Jeti">
                </div>
                <div class="card-back">
                    <h1>Jeti</h1>
                </div>
            </div>
        </div>

        <div class="cards">
            <div class="card-container">
                <div class="card-front">
                    <img src="assets/img/beasts/nagylab.jpg" alt="Nagyláb">
                </div>
                <div class="card-back">
                    <h1>Nagyláb</h1>
                </div>
            </div>
        </div>

        <div class="cards">
            <div class="card-container">
                <div class="card-front">
                    <img src="assets/img/beasts/kraken.jpg" alt="Loch Ness-i szörny">
                </div>
                <div class="card-back">
                    <h1>Kraken</h1>
                </div>
            </div>
        </div>

        <div class="cards">
            <div class="card-container">
                <div class="card-front">
                    <img src="assets/img/beasts/lochnessiszorny.jpg" alt="Loch Ness-i szörny">
                </div>
                <div class="card-back">
                    <h1>Loch Ness-i szörny</h1>
                </div>
            </div>
        </div>

        <div class="cards">
            <div class="card-container">
                <div class="card-front">
                    <img src="assets/img/beasts/mongolhalalfereg.jpg" alt="Mongol halálféreg">
                </div>
                <div class="card-back">
                    <h1>Mongol halálféreg</h1>
                </div>
            </div>
        </div>

        <div class="cards">
            <div class="card-container">
                <div class="card-front">
                    <img src="assets/img/beasts/tatzelwurm.jpg" alt="Tatzelwurm">
                </div>
                <div class="card-back">
                    <h1>Tatzelwurm</h1>
                </div>
            </div>
        </div>

        <div class="cards">
            <div class="card-container">
                <div class="card-front">
                    <img src="assets/img/beasts/chupacabra.jpg" alt="Chupacabra">
                </div>
                <div class="card-back">
                    <h1>Chupacabra</h1>
                </div>
            </div>
        </div>
    </section>

    <div class="beasts-ajanlat">
        <p>További információkhoz ajánljuk: </p>
        <p class="beasts-link"><a href="https://www.youtube.com/watch?v=1GaGNsNe23g&list=PL2bGVuWRqAkClRXsPSaK0u0frioLPbjtV" target="_blank">Kriptid lényekről lejátszási lista.</a></p>
    </div>
</div>

<?php
include_once "common/footer.php";
?>
</body>
</html>