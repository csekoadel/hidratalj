<?php

class CartItem {
    private string $name;
    private int $quantity;
    private int $price;

    //construct
    public function __construct(Beast $beast, int $quantity=1) {
        $this->name = $beast->getName();
        $this->quantity = $quantity;
        $this->price = $this->quantity * $beast->getPrice();
    }

    //getters & setters
    public function getName(): string
    {
        return $this->name;
    }

    public function setName(string $name): void
    {
        $this->name = $name;
    }

    public function getQuantity(): int
    {
        return $this->quantity;
    }

    public function setQuantity(int $quantity): void
    {
        $this->quantity = $quantity;
    }

    public function getPrice()
    {
        return $this->price;
    }

    public function setPrice($price): void
    {
        $this->price = $price;
    }

    //toString
    public function __toString(): string {
        return $this->quantity . " " . strtolower($this->name) . " (" . $this->price . " Ft)";
    }
}