<?php

class Order {
    private string $customer;
    private array $orderContent;
    private DateTime $orederDate;
    private bool $performed;

    //construct
    public function __construct(string $username, array $orderContent) {
        $this->customer = $username;
        $this->orderContent = $orderContent;
        $this->performed = false;

        $this->orederDate = new DateTime();
        $this->orederDate->setTimezone(new DateTimeZone("Europe/Budapest"));
    }

    //getters & setters
    public function getCustomer(): string
    {
        return $this->customer;
    }

    public function setCustomer(string $customer): void
    {
        $this->customer = $customer;
    }

    public function getOrderContent(): array
    {
        return $this->orderContent;
    }

    public function setOrderContent(array $orderContent): void
    {
        $this->orderContent = $orderContent;
    }

    public function getOrederDate(): DateTime
    {
        return $this->orederDate;
    }

    public function setOrederDate(DateTime $orederDate): void
    {
        $this->orederDate = $orederDate;
    }

    public function isPerformed(): bool
    {
        return $this->performed;
    }

    public function setPerformed(bool $performed): void
    {
        $this->performed = $performed;
    }

}