<?php

class User{
    private string $username;
    private string $password;
    private string $email;
    private int $yearOfBirth;
    private string $gender;
    private array $cart;

    //construct
    public function __construct(string $username, string $password, string $email, int $yearOfBirth=1969, string $gender="other"){
        $this->username = $username;
        $this->password = $password;
        $this->email = $email;
        $this->yearOfBirth = $yearOfBirth;
        $this->gender = $gender;
        $this->cart = [];
    }

    //getters setters
    public function getUsername(): string
    {
        return $this->username;
    }

    public function setUsername(string $username): void
    {
        $this->username = $username;
    }

    public function getPassword(): string
    {
        return $this->password;
    }

    public function setPassword(string $password): void
    {
        $this->password = $password;
    }

    public function getEmail(): string
    {
        return $this->email;
    }

    public function setEmail(string $email): void
    {
        $this->email = $email;
    }

    public function getYearOfBirth(): int
    {
        return $this->yearOfBirth;
    }

    public function setYearOfBirth(int $yearOfBirth): void
    {
        $this->yearOfBirth = $yearOfBirth;
    }

    public function getGender(): string
    {
        return $this->gender;
    }

    public function setGender(string $gender): void
    {
        $this->gender = $gender;
    }

    public function getCart(): array
    {
        return $this->cart;
    }

    public function setCart(array $cart): void
    {
        $this->cart = $cart;
    }

    //toString
    public function __toString(): string {
        return $this->username . ", születési év: " . $this->yearOfBirth . ", e-mail cím: " .
            $this->email . ", neme: " . $this->gender;
    }


    public function putInCart(CartItem $newItem): void{
        foreach ($this->cart as $item) {
            if($item->getName() === $newItem->getName()) {
                $item->setQuantity($item->getQuantity() + 1);
                $item->setPrice($item->getPrice() + $newItem->getPrice());
                return;
            }
        }
        $this->cart[] = $newItem;
    }
}