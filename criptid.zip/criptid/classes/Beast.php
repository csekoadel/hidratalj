<?php

class Beast {
    private string $name;
    private int $price;
    private array $equipment;

    //construct
    public function __construct(string $name, int $price, array $equipment) {
        $this->name = $name;
        $this->price = $price;
        $this->equipment = $equipment;
    }

    //getters & setters
    public function getName(): string
    {
        return $this->name;
    }

    public function setName(string $name): void
    {
        $this->name = $name;
    }

    public function getPrice(): int
    {
        return $this->price;
    }

    public function setPrice(int $price): void
    {
        $this->price = $price;
    }

    public function getEquipment(): array
    {
        return $this->equipment;
    }

    public function setEquipment(array $equipment): void
    {
        $this->equipment = $equipment;
    }

    //toString
    public function __toString(): string {
        return $this->name . ", ár: " . $this->price . " forint, eszkozok: " . implode(", ", $this->equipment);
    }
}