<?php
include_once "classes/User.php";
include_once "common/functions.php";
session_start();
?>

    <!DOCTYPE html>
    <html lang="hu">
    <head>
        <title>Rólunk</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" href="assets/img/icon.png">
        <link rel="stylesheet" href="assets/css/style.css">
    </head>
    <body>
<?php
include_once "common/header.php";
generateNav("about");
?>

<div class="top-container-about">
    <h1>
        <div class="fade-in-text">
            <div style="background-color:rgba(22, 43, 46, 0.5); text-align:center; vertical-align: middle; padding:20px 47px"> Ismerkedjetek meg kis létszámú csapatunkkal:</div>
        </div>
    </h1>
    <div class="column">
        <div class="card">
            <img src="assets/img/Team.Cinti.jpg" alt="Cinti">
            <div class="container">
                <table>
                    <tr>
                        <th>Név :</th>
                        <td>Farkas Cintia</td>
                    </tr>
                    <tr>
                        <th>Vadász név :</th>
                        <td>One Punch man</td>
                    </tr>
                    <tr>
                        <th>Életkor :</th>
                        <td>19 </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <div class="column">
        <div class="card">
            <img src="assets/img/Team.Dajana.jpg" alt="Dajana">
            <div class="container">
                <table>
                    <tr>
                        <th>Név :</th>
                        <td>Fehér Dajana</td>
                    </tr>
                    <tr>
                        <th>Vadász név :</th>
                        <td>Banánvető</td>
                    </tr>
                    <tr>
                        <th>Életkor :</th>
                        <td>24</td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>


<?php
include_once "common/footer.php";
?>
    </body>
</html>
