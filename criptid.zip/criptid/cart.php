<?php
    include_once "classes/User.php";
    include_once "classes/Beast.php";
    include_once "classes/CartItem.php";
    include_once "classes/Order.php";
    include_once "common/functions.php";
    session_start();

    if (!isset($_SESSION["user"])) {
        header("Location: login.php");
    }

    $user = $_SESSION["user"];

    $cart = $user->getCart();

    if (isset($_GET["delete-from-cart-btn"])) {
        $deleteItem = $_GET["item-name"];
        $newCart = [];

        foreach ($cart as $item) {
            if ($item->getName() !== $deleteItem) {
                $newCart[] = $item;
            }
        }

        $user->setCart($newCart);
        editUsers("data/users.txt", $user);
        header("Location: cart.php");
    }

    if (isset($_GET["order-btn"])) {
        $orders = loadData("data/orders.txt");

        $order = new Order($user->getUsername(), $cart);
        $orders[] = $order;
        saveData("data/orders.txt", $orders);

        $user->setCart([]);
        editUsers("data/users.txt", $user);
        header("Location: cart.php?success=true");
    }
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <title>Kosaram</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="assets/img/icon.png">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php
        include_once "common/header.php";
        generateNav("cart");
    ?>

    <main>
        <h1 class="kozepre">Kosaram</h1>
        <hr>

        <?php
            if (isset($_GET["success"])) {
                echo "<div class='success'><p>Sikeres rendelés!</p></div>";
            }
        ?>

        <?php if (count($cart) > 0) { ?>
            <table id="cart-table">
                <tr>
                    <th>Kriptid neve</th>
                    <th>Mennyiség</th>
                    <th>Ár</th>
                    <th>Törlés</th>
                </tr>
                <?php foreach ($cart as $item) { ?>
                <tr>
                    <td><?php echo $item->getName(); ?></td>
                    <td><?php echo $item->getQuantity(); ?></td>
                    <td><?php echo $item->getPrice() . "Ft"; ?></td>
                    <td>
                        <form action="cart.php" method="GET" class="cart-delete-form">
                            <input type="hidden" name="item-name" value="<?php echo $item->getName(); ?>">
                            <input type="submit" name="delete-from-cart-btn" value="Törlés" class="delete-btn">
                        </form>
                    </td>
                </tr>
                <?php } ?>
                <tr class="total-sum">
                    <th colspan="4">Végösszeg: <?php echo total($cart) ?>Ft</th>
                </tr>
            </table>

            <form action="cart.php" method="GET" class="order-form">
                <input type="submit" name="order-btn" class="order-btn" value="Rendelés">
            </form>
        <?php } else { ?>
            <p class="center strong">A kosarad jelenleg üres!</p>
        <?php } ?>
    </main>

    <?php
        include_once "common/footer.php";
    ?>
</body>
</html>